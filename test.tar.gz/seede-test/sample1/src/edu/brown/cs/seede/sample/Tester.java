/********************************************************************************/
/*                                                                              */
/*              Main.java                                                       */
/*                                                                              */
/*      Default implementation of main                                          */
/*                                                                              */
/********************************************************************************/



package edu.brown.cs.seede.sample;

import org.junit.Test;
import org.junit.Assert;


public class Tester
{


/********************************************************************************/
/*                                                                              */
/*      Main program                                                            */
/*                                                                              */
/********************************************************************************/

public static void main(String [] args)
{
   gcd(1234283,28492);
}


private static int gcd(int a,int b)
{
   while (b > 0) {
      if (a < b) {
         int y = a;
         a = b;
         b = y;
       }
      int x = a % b;
      a = b;
      b = x;
    }
   return a;
}



@Test
public void test1()
{
   Assert.assertEquals(gcd(100,64),4);
}



}       // end ofclass Main
                



/* end of Main.java */
