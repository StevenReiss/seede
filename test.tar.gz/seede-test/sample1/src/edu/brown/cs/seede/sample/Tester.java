/********************************************************************************/
/*                                                                              */
/*              Main.java                                                       */
/*                                                                              */
/*      Default implementation of main                                          */
/*                                                                              */
/********************************************************************************/



package edu.brown.cs.seede.sample;

import org.junit.Test;
import org.junit.Assert;
import java.util.*;

public class Tester
{


/********************************************************************************/
/*                                                                              */
/*      Main program                                                            */
/*                                                                              */
/********************************************************************************/

public static void main(String [] args)
{
   gcd(1234283,28492);
}


private static int gcd(int a,int b)
{
   while (b > 0) {
      if (a < b) {
         int y = a;
         a = b;
         b = y;
       }
      int x = a % b;
      a = b;
      b = x;
    }
   return a;
}



@Test
public void test1()
{
   Assert.assertEquals(gcd(100,64),4);
}


/********************************************************************************/
/*                                                                              */
/*      Class test                                                              */
/*                                                                              */
/********************************************************************************/

private IntSet 		int_set;


private static class IntSet {
   private Vector<Integer> els;
   
   IntSet() {
      els = new Vector<Integer>();
   }
   void insert(int x) {
      Integer y = x;
      if (getIndex(y) < 0) els.add(y);
   }
   void remove(int x) {
      int i = getIndex(x);
      if (i < 0) return;
      els.set(i, els.lastElement());
      els.remove(els.size()-1);
   }
   boolean isIn(int x) {
      return getIndex(x) >= 0;
   }
   private int getIndex(Integer x) {
      for (int i = 0; i < els.size(); i++) {
	 if (x.equals(els.get(i))) return i;
      }
      return -1;
   }
   int size() {
      return els.size();
   }
   int choose() throws Error {
      if (els.size() == 0) throw new Error("Intset.choose");
      else return els.lastElement();
   }
   
}	// end of inner class IntSet


public Tester() 
{
   int_set = new IntSet();
}

@Test
public void test2()
{
   int_set.insert(4);
   int_set.insert(8);
   int_set.insert(16);
   int_set.insert(24);
   Assert.assertEquals(int_set.size(),4);
   int_set.insert(8);
   Assert.assertEquals(int_set.size(),4);
   int_set.remove(10);
   Assert.assertEquals(int_set.size(),4); 
   int_set.remove(24);
   Assert.assertEquals(int_set.size(),3); 
   Assert.assertTrue(int_set.isIn(8));
   Assert.assertFalse(int_set.isIn(3));
   int v = int_set.choose();
   Assert.assertTrue(v == 4 || v == 8 || v == 16);
   IntSet nins = new IntSet();
   Assert.assertEquals(nins.size(),0);
}



}       // end ofclass Tester
                



/* end of Main.java */
